import base64

addon_name   = base64.b64decode('W0NPTE9SIGN5YW5dNzE3IExpdmUgVFZbL0NPTE9SXQ==')
addon_id     = base64.b64decode('cGx1Z2luLnZpZGVvLjcxN2xpdmV0dg==')

host         = base64.b64decode('aHR0cDovL21lZXRpbmdicm9zLmNvbQ==')
port         = base64.b64decode('MjA4Ng==')